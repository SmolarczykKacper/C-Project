﻿using System.Text.Json;

namespace Saper.Shared;

/// <summary>
/// <<sumary>> Pomocnicza klasa do serializacji i deserializacji komunikatów gry.
/// Używa JSON i dodaje znak nowej linii na końcu przy wysyłaniu.
/// </summary>
public static class Protocol
{
    /// <summary>
    /// <<sumary>> Serializuje obiekt do JSON i dodaje znak nowej linii.
    /// </summary>
    public static string ToLine<T>(T obj) => JsonSerializer.Serialize(obj) + "\n";

    /// <summary>
    /// <<sumary>> Deserializuje JSON do obiektu typu T.
    /// </summary>
    public static T? From<T>(string json) => JsonSerializer.Deserialize<T>(json);
}

/// <summary>
/// <<sumary>> Bazowy rekord dla wszystkich komunikatów.
/// Zawiera pole "type" określające rodzaj wiadomości.
/// </summary>
public abstract record BaseMsg(string type);

/// <summary>
/// <<sumary>> Żądanie utworzenia nowej gry (wysyłane od klienta do serwera).
/// Zawiera nick gracza oraz wymiary planszy i liczbę min.
/// </summary>
public record CreateGameReq(string player, int width, int height, int mines) : BaseMsg("CreateGameReq");

/// <summary>
/// <<sumary>> Odpowiedź na utworzenie gry (od serwera do klienta).
/// Zawiera ID gry, wymiary, liczbę min i seed generatora.
/// </summary>
public record CreateGameResp(string gameId, int width, int height, int mines, int seed) : BaseMsg("CreateGameResp");

/// <summary>
/// <<sumary>> Żądanie odkrycia pola (x, y) w danej grze.
/// </summary>
public record RevealReq(string gameId, int x, int y) : BaseMsg("RevealReq");

/// <summary>
/// <<sumary>> Żądanie postawienia lub usunięcia flagi na polu (x, y) w danej grze.
/// </summary>
public record ToggleFlagReq(string gameId, int x, int y) : BaseMsg("ToggleFlagReq");

/// <summary>
/// <<sumary>> Informacja o otwartym polu: współrzędne i liczba min w sąsiedztwie (adj = -1 oznacza minę).
/// </summary>
public record CellOpen(int x, int y, int adj);

/// <summary>
/// <<sumary>> Informacja o stanie flagi na polu: współrzędne i bool flagged.
/// </summary>
public record CellFlag(int x, int y, bool flagged);

/// <summary>
/// <<sumary>> Zmiana stanu gry po ruchu.
/// Zawiera listę otwartych pól, zmiany flag, status końca gry, wygranej, liczby min pozostałych i odsłoniętych pól.
/// </summary>
public record GameDelta(
    string gameId,
    CellOpen[] opened,
    CellFlag[] flags,
    bool gameOver,
    bool? won,
    int minesLeft,
    int revealed
) : BaseMsg("GameDelta");

/// <summary>
/// <<sumary>> Żądanie pobrania najlepszych wyników (TOP N) z bazy.
/// Można filtrować po szerokości, wysokości i liczbie min.
/// </summary>
public record GetTopReq(int? width, int? height, int? mines, int limit) : BaseMsg("GetTopReq");

/// <summary>
/// <<sumary>> Pojedynczy wpis w tabeli wyników.
/// Zawiera nick, wymiary planszy, liczbę min, ruchy, czas gry, wygraną i datę zakończenia.
/// </summary>
public record TopScore(
    string player,
    int width,
    int height,
    int mines,
    int moves,
    int durationMs,
    bool won,
    string finishedAt
);

/// <summary>
/// <<sumary>> Odpowiedź serwera z listą najlepszych wyników.
/// </summary>
public record GetTopResp(TopScore[] scores) : BaseMsg("GetTopResp");

/// <summary>
/// <<sumary>> Komunikat błędu z tekstem wiadomości.
/// </summary>
public record ErrorMsg(string message) : BaseMsg("Error");
