﻿using System;
using System.Collections.Generic;

namespace Saper.Shared;

public enum CellState { Hidden, Revealed, Flagged }

/// <summary>
/// <<sumary>> Logika planszy gry w Sapera.
/// Przechowuje miny, liczy sąsiadów, obsługuje odkrywanie pól, strefę bezpieczeństwa i stawianie flag.
/// </summary>
public sealed class Board
{
    public int Width { get; }
    public int Height { get; }
    public int Mines { get; }
    public int Seed { get; }
    public int RevealedCount { get; private set; }
    public int FlagsPlaced { get; private set; }
    public int MinesLeft => Math.Max(0, Mines - FlagsPlaced);
    public bool IsGameOver { get; private set; }
    public bool? PlayerWon { get; private set; }

    private readonly bool[,] _mine;
    private readonly int[,] _adj;
    private readonly CellState[,] _st;

    private bool _generated = false;
    private int _firstClickX, _firstClickY;

    /// <summary>
    /// <<sumary>> Tworzy planszę o podanych wymiarach, liczbie min i seeda RNG.
    /// Miny są rozmieszczane dopiero przy pierwszym ruchu (Reveal).
    /// </summary>
    public Board(int w, int h, int mines, int seed)
    {
        if (w < 5 || h < 5) throw new ArgumentException("Minimalny rozmiar 5x5");
        if (mines < 1 || mines >= w * h) throw new ArgumentException("Zła liczba min");
        Width = w; Height = h; Mines = mines; Seed = seed;
        _mine = new bool[w, h];
        _adj = new int[w, h];
        _st = new CellState[w, h];
    }

    /// <summary>
    /// <<sumary>> Wykonuje akcję dla wszystkich sąsiadów (8 kierunków) pola (x, y).
    /// </summary>
    private void ForN(int x, int y, Action<int, int> a)
    {
        for (int dy = -1; dy <= 1; dy++)
            for (int dx = -1; dx <= 1; dx++)
            {
                if (dx == 0 && dy == 0) continue;
                int nx = x + dx, ny = y + dy;
                if (nx >= 0 && ny >= 0 && nx < Width && ny < Height) a(nx, ny);
            }
    }

    /// <summary>
    /// <<sumary>> Rozmieszcza miny w losowych polach z pominięciem
    /// strefy bezpieczeństwa 3×3 wokół pierwszego kliknięcia.
    /// Następnie oblicza liczby min wokół każdego pola.
    /// </summary>
    private void GenerateWithSafeZone(int seed, int safeX, int safeY)
    {
        var rnd = new Random(seed);

        var forbidden = new bool[Width, Height];
        forbidden[safeX, safeY] = true;
        ForN(safeX, safeY, (nx, ny) => forbidden[nx, ny] = true);

        var pool = new List<(int x, int y)>(Width * Height);
        for (int y = 0; y < Height; y++)
            for (int x = 0; x < Width; x++)
                if (!forbidden[x, y]) pool.Add((x, y));

        if (Mines > pool.Count)
            throw new InvalidOperationException($"Za dużo min ({Mines}) względem dostępnych pól ({pool.Count}) po wycięciu strefy 3×3.");

        for (int i = pool.Count - 1; i > 0; i--)
        {
            int j = rnd.Next(i + 1);
            (pool[i], pool[j]) = (pool[j], pool[i]);
        }

        for (int i = 0; i < Mines; i++)
        {
            var (mx, my) = pool[i];
            _mine[mx, my] = true;
        }

        for (int y = 0; y < Height; y++)
            for (int x = 0; x < Width; x++)
            {
                if (_mine[x, y]) { _adj[x, y] = -1; continue; }
                int c = 0; ForN(x, y, (nx, ny) => { if (_mine[nx, ny]) c++; });
                _adj[x, y] = c;
            }
    }

    /// <summary>
    /// <<sumary>> Odkrywa pole (x, y):
    /// - przy pierwszym ruchu rozmieszcza miny z bezpieczną strefą,
    /// - jeśli mina → koniec gry,
    /// - jeśli puste pole → uruchamia FloodOpen().
    /// Zwraca listę pól otwartych w tym ruchu.
    /// </summary>
    public IEnumerable<CellOpen> Reveal(int x, int y)
    {
        if (IsGameOver || _st[x, y] == CellState.Revealed) yield break;
        if (_st[x, y] == CellState.Flagged) yield break;

        if (!_generated)
        {
            _generated = true;
            _firstClickX = x;
            _firstClickY = y;
            GenerateWithSafeZone(Seed, x, y);
        }

        if (_mine[x, y])
        {
            _st[x, y] = CellState.Revealed;
            IsGameOver = true;
            PlayerWon = false;
            RevealedCount++;
            yield return new CellOpen(x, y, -1);
            yield break;
        }

        foreach (var c in FloodOpen(x, y))
            yield return c;

        if (RevealedCount == Width * Height - Mines)
        {
            IsGameOver = true;
            PlayerWon = true;
        }
    }

    /// <summary>
    /// <<sumary>> Otwiera pole i (rekurencyjnie) sąsiadów,
    /// jeśli pole ma wartość 0 (bez min obok).
    /// Zwraca wszystkie odsłonięte pola.
    /// </summary>
    private IEnumerable<CellOpen> FloodOpen(int sx, int sy)
    {
        var q = new Queue<(int x, int y)>();
        void Open(int x, int y)
        {
            if (_st[x, y] != CellState.Hidden) return;
            _st[x, y] = CellState.Revealed;
            RevealedCount++;
        }

        q.Enqueue((sx, sy));
        while (q.Count > 0)
        {
            var (x, y) = q.Dequeue();
            if (_st[x, y] == CellState.Revealed) continue;

            Open(x, y);
            int a = _adj[x, y];
            yield return new CellOpen(x, y, a);

            if (a == 0)
            {
                ForN(x, y, (nx, ny) =>
                {
                    if (_st[nx, ny] == CellState.Hidden && !_mine[nx, ny])
                        q.Enqueue((nx, ny));
                });
            }
        }
    }

    /// <summary>
    /// <<sumary>> Przełącza stan flagi na polu (x, y):
    /// - jeśli ukryte → ustawia flagę,
    /// - jeśli flaga → usuwa flagę.
    /// Zwraca obiekt <see cref="CellFlag"/> z aktualnym stanem.
    /// </summary>
    public CellFlag ToggleFlag(int x, int y)
    {
        if (IsGameOver || _st[x, y] == CellState.Revealed)
            return new CellFlag(x, y, _st[x, y] == CellState.Flagged);

        if (_st[x, y] == CellState.Flagged)
        {
            _st[x, y] = CellState.Hidden;
            FlagsPlaced = Math.Max(0, FlagsPlaced - 1);
            return new CellFlag(x, y, false);
        }
        else
        {
            _st[x, y] = CellState.Flagged;
            FlagsPlaced++;
            return new CellFlag(x, y, true);
        }
    }
}
