﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Saper.Shared;

namespace Saper.Client.Wpf
{
    public partial class MainWindow : Window
    {
        private TcpClient? _client;
        private StreamReader? _reader;
        private StreamWriter? _writer;
        private CancellationTokenSource? _cts;

        private string? _gameId;
        private int _w, _h;
        private Button[,]? _buttons;

        private readonly HashSet<(int x, int y)> _flags = new();

        public MainWindow() => InitializeComponent();

        /// <summary>
        /// <<sumary>> Nawiązuje połączenie z serwerem (host/port z UI), tworzy strumienie,
        /// uruchamia asynchroniczną pętlę odbiorczą i przełącza przyciski w stanie „połączono”.
        /// Błędy sieciowe są łapane i wyświetlane w pasku statusu.
        /// </summary>
        private async void ConnectBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var host = HostBox.Text.Trim();
                var port = int.Parse(PortBox.Text.Trim());
                _client?.Close(); _client = new TcpClient();
                await _client.ConnectAsync(host, port);
                var stream = _client.GetStream();
                _reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
                _writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };
                _cts = new CancellationTokenSource();
                _ = Task.Run(() => ReceiveLoopAsync(_cts.Token));
                Status("Połączono.");
                NewBtn.IsEnabled = true; ConnectBtn.IsEnabled = false; ScoresBtn.IsEnabled = true;
            }
            catch (Exception ex) { Status("Błąd połączenia: " + ex.Message); }
        }

        /// <summary>
        /// <<sumary>> Prosi serwer o utworzenie nowej gry (CreateGameReq) z nickiem i parametrami
        /// (szerokość, wysokość, liczba min). Czyści lokalny zestaw flag.
        /// Oczekiwane jest CreateGameResp, które wywoła BuildBoard.
        /// </summary>
        private async void NewBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_writer is null) return;
            int w = int.Parse(WBox.Text), h = int.Parse(HBox.Text), m = int.Parse(MBox.Text);
            string player = string.IsNullOrWhiteSpace(NickBox.Text) ? "guest" : NickBox.Text.Trim();
            _flags.Clear();
            await _writer.WriteAsync(Protocol.ToLine(new CreateGameReq(player, w, h, m)));
        }

        /// <summary>
        /// <<sumary>> Wysyła do serwera żądanie pobrania Top 10 (GetTopReq) dla
        /// aktualnych parametrów planszy. Odpowiedź GetTopResp obsłuży ShowScores.
        /// </summary>
        private async void ScoresBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_writer is null) return;
            int w = int.Parse(WBox.Text), h = int.Parse(HBox.Text), m = int.Parse(MBox.Text);
            await _writer.WriteAsync(Protocol.ToLine(new GetTopReq(w, h, m, 10)));
        }

        /// <summary>
        /// <<sumary>> Pętla odbiorcza: czyta linie JSON, rozpoznaje typ i deleguje:
        /// CreateGameResp → BuildBoard; GameDelta → ApplyDelta; GetTopResp → ShowScores; Error → Status.
        /// Zmiany UI wykonywane na Dispatcherze. Sprząta po rozłączeniu.
        /// </summary>
        private async Task ReceiveLoopAsync(CancellationToken ct)
        {
            try
            {
                while (!ct.IsCancellationRequested && _reader is not null)
                {
                    var line = await _reader.ReadLineAsync(); if (line is null) break;
                    using var doc = JsonDocument.Parse(line);
                    if (!doc.RootElement.TryGetProperty("type", out var tp)) continue;
                    var type = tp.GetString();
                    switch (type)
                    {
                        case "CreateGameResp":
                            {
                                var msg = Protocol.From<CreateGameResp>(line)!;
                                Dispatcher.Invoke(() => BuildBoard(msg));
                                break;
                            }
                        case "GameDelta":
                            {
                                var msg = Protocol.From<GameDelta>(line)!;
                                Dispatcher.Invoke(() => ApplyDelta(msg));
                                break;
                            }
                        case "GetTopResp":
                            {
                                var msg = Protocol.From<GetTopResp>(line)!;
                                Dispatcher.Invoke(() => ShowScores(msg));
                                break;
                            }
                        case "Error":
                            {
                                var err = Protocol.From<ErrorMsg>(line)!;
                                Dispatcher.Invoke(() => Status("Błąd: " + err.message));
                                break;
                            }
                    }
                }
            }
            catch (IOException) { }
            catch (Exception ex) { Dispatcher.Invoke(() => Status("Błąd odbioru: " + ex.Message)); }
            finally
            {
                Dispatcher.Invoke(() => { Status("Rozłączono."); NewBtn.IsEnabled = false; ConnectBtn.IsEnabled = true; ScoresBtn.IsEnabled = false; });
                _client?.Close();
            }
        }

        /// <summary>
        /// <<sumary>> Buduje siatkę przycisków (UniformGrid) wg rozmiaru z CreateGameResp,
        /// resetuje zbiór flag i czyści wcześniejszą planszę. Po zakończeniu wyświetla status z parametrami.
        /// </summary>
        private void BuildBoard(CreateGameResp msg)
        {
            _gameId = msg.gameId; _w = msg.width; _h = msg.height;
            BoardGrid.Columns = _w; BoardGrid.Rows = _h; BoardGrid.Children.Clear();
            _buttons = new Button[_w, _h];
            _flags.Clear();

            for (int y = 0; y < _h; y++)
                for (int x = 0; x < _w; x++)
                {
                    var b = new Button
                    {
                        Margin = new Thickness(1),
                        MinWidth = 24,
                        MinHeight = 24,
                        Padding = new Thickness(0),
                        Background = Brushes.LightGray,
                        Foreground = Brushes.Black,
                        FontWeight = FontWeights.Bold
                    };
                    b.Tag = (x, y);
                    b.Content = "";
                    b.Click += Cell_LeftClick;
                    b.MouseRightButtonUp += Cell_RightClick;
                    BoardGrid.Children.Add(b);
                    _buttons[x, y] = b;
                }
            Status($"Utworzono grę {_w}x{_h}, miny: {msg.mines}");
        }

        /// <summary>
        /// <<sumary>> Obsługa lewego kliknięcia pola.
        /// Jeśli pole jest oflagowane (w _flags), ruch jest ignorowany.
        /// W przeciwnym razie wysyłany jest RevealReq do serwera.
        /// </summary>
        private async void Cell_LeftClick(object sender, RoutedEventArgs e)
        {
            if (_writer is null || _gameId is null) return;
            var (x, y) = ((int, int))((Button)sender).Tag;
            if (_flags.Contains((x, y))) return; // nie odkrywaj, jeśli flaga
            await _writer.WriteAsync(Protocol.ToLine(new RevealReq(_gameId, x, y)));
        }

        /// <summary>
        /// <<sumary>> Obsługa prawego kliknięcia pola.
        /// Zawsze wysyła ToggleFlagReq do serwera, który odsyła delty z potwierdzeniem.
        /// </summary>
        private async void Cell_RightClick(object sender, MouseButtonEventArgs e)
        {
            if (_writer is null || _gameId is null) return;
            var (x, y) = ((int, int))((Button)sender).Tag;
            await _writer.WriteAsync(Protocol.ToLine(new ToggleFlagReq(_gameId, x, y)));
        }

        /// <summary>
        /// <<sumary>> Naniesienie delty gry na UI:
        /// - otwarte pola: ustaw treść (bomby czerwone, liczby kolorowane 1–8), zablokuj przyciski,
        /// - flagi: włącz/wyłącz znacznik 🚩, pozostawiając możliwość ponownego kliknięcia PPM,
        /// - aktualizacja statusu lub zamknięcie planszy, jeśli graOver.
        /// </summary>
        private void ApplyDelta(GameDelta d)
        {
            if (_buttons is null) return;

            // Odsłonięte pola 
            foreach (var o in d.opened)
            {
                var b = _buttons[o.x, o.y];
                b.IsEnabled = false;

                if (o.adj < 0)
                {
                    b.Content = "💣";
                    b.Background = Brushes.Red;
                    b.Foreground = Brushes.Black;
                }
                else
                {
                    b.Background = Brushes.White;
                    if (o.adj == 0)
                    {
                        b.Content = "";
                        b.Foreground = Brushes.Black;
                    }
                    else
                    {
                        b.Content = o.adj.ToString();
                        b.Foreground = o.adj switch
                        {
                            1 => Brushes.Blue,
                            2 => Brushes.Green,
                            3 => Brushes.Red,
                            4 => Brushes.DarkBlue,
                            5 => Brushes.DarkRed,
                            6 => Brushes.Teal,
                            7 => Brushes.Black,
                            8 => Brushes.Gray,
                            _ => Brushes.Black
                        };
                    }
                }
                _flags.Remove((o.x, o.y));
            }

            // Flagi (toggle)
            foreach (var f in d.flags)
            {
                var b = _buttons[f.x, f.y];

                if (f.flagged)
                {
                    b.Content = "🚩";
                    b.Background = Brushes.Khaki;
                    b.Foreground = Brushes.Black;
                    _flags.Add((f.x, f.y));
                    b.IsEnabled = true; // zostaw aktywne, by dało się zdjąć flagę
                }
                else
                {
                    b.Content = "";
                    if (b.IsEnabled) 
                    {
                        b.Background = Brushes.LightGray;
                        b.Foreground = Brushes.Black;
                    }
                    _flags.Remove((f.x, f.y));
                    b.IsEnabled = true;
                }
            }

            if (d.gameOver)
            {
                foreach (var btn in _buttons) btn.IsEnabled = false;
                Status(d.won == true ? "Wygrana!" : "Przegrana :(");
            }
            else
            {
                Status($"Miny: {d.minesLeft} | Odkryte: {d.revealed}");
            }
        }

        /// <summary>
        /// <<sumary>> Tworzy i pokazuje modalne okno z tabelą Top 10 (ScoresWindow)
        /// na podstawie danych z GetTopResp.
        /// </summary>
        private void ShowScores(GetTopResp resp)
        {
            var win = new ScoresWindow(resp.scores);
            win.Owner = this;
            win.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            win.ShowDialog();
        }

        /// <summary>
        /// <<sumary>> Ustawia komunikat w pasku statusu (TextBlock StatusText).
        /// </summary>
        private void Status(string s) => StatusText.Text = s;
    }
}