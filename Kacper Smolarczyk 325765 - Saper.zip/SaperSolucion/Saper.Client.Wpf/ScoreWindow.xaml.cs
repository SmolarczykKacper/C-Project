﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Saper.Shared;

namespace Saper.Client.Wpf
{
    public partial class ScoresWindow : Window
    {
        public class Row
        {
            public int Rank { get; set; }
            public string Player { get; set; } = "";
            public string Size { get; set; } = "";
            public int Moves { get; set; }
            public double Seconds { get; set; }
            public string Finished { get; set; } = "";
        }

        /// <summary>
        /// <<sumary>> Konstruktor okna wyników.
        /// Przyjmuje tablicę wyników (TopScore), zamienia je na listę wierszy do DataGrid,
        /// formatuje czas (ms → sekundy z 2 miejscami) i datę (ISO z 'T' → spacja),
        /// a następnie ustawia ItemsSource siatki.
        /// </summary>
        public ScoresWindow(TopScore[] scores)
        {
            InitializeComponent();

            var rows = new List<Row>();
            int i = 1;
            foreach (var s in scores ?? Array.Empty<TopScore>())
            {
                rows.Add(new Row
                {
                    Rank = i++,
                    Player = s.player,
                    Size = $"{s.width}x{s.height} / {s.mines}",
                    Moves = s.moves,
                    Seconds = Math.Round(s.durationMs / 1000.0, 2),
                    Finished = s.finishedAt.Replace('T', ' ') // uproszczone ISO
                });
            }

            Grid.ItemsSource = rows;
        }
    }
}
