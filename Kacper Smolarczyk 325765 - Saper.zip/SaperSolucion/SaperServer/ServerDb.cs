﻿using Microsoft.EntityFrameworkCore;

namespace Saper.Server;

/// <summary>
/// <<sumary>> Kontekst bazy danych serwera gry.
/// Zawiera konfigurację EF Core dla tabeli gier i definiuje połączenie z bazą SQLite.
/// </summary>
public class ServerDb : DbContext
{
    /// <summary>
    /// <<sumary>> Zbiór encji reprezentujących gry (historia + wyniki).
    /// </summary>
    public DbSet<GameEntity> Games => Set<GameEntity>();

    /// <summary>
    /// <<sumary>> Konfiguracja połączenia z bazą danych SQLite (plik `saper.db`).
    /// </summary>
    protected override void OnConfiguring(DbContextOptionsBuilder options)
        => options.UseSqlite("Data Source=saper.db");

    /// <summary>
    /// <<sumary>> Konfiguracja modelu encji:
    /// - klucz główny `Id` bez automatycznego generowania,
    /// - maksymalna długość PlayerName (64),
    /// - indeksy: PlayerName, FinishedAt, oraz kombinacja Won+DurationMs.
    /// </summary>
    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<GameEntity>().HasKey(x => x.Id);
        b.Entity<GameEntity>().Property(x => x.Id).ValueGeneratedNever();

        b.Entity<GameEntity>().Property(x => x.PlayerName).HasMaxLength(64);
        b.Entity<GameEntity>().HasIndex(x => x.PlayerName);
        b.Entity<GameEntity>().HasIndex(x => x.FinishedAt);
        b.Entity<GameEntity>().HasIndex(x => new { x.Won, x.DurationMs });
    }
}

/// <summary>
/// <<sumary>> Encja reprezentująca pojedynczą grę w bazie danych:
/// identyfikator, parametry planszy, dane gracza, czas trwania i wynik.
/// </summary>
public class GameEntity
{
    public string Id { get; set; } = default!;
    public string PlayerName { get; set; } = "guest";
    public DateTime StartedAt { get; set; }
    public DateTime? FinishedAt { get; set; }
    public bool? Won { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public int Mines { get; set; }
    public int Seed { get; set; }
    public int Moves { get; set; }
    public int DurationMs { get; set; }
}
