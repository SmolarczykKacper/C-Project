﻿using System.Net;
using System.Net.Sockets;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Saper.Shared;
using Saper.Server;

internal class Program
{
    private const int Port = 5099; // ten sam wpisz w kliencie
    private static readonly Dictionary<string, (Board board, DateTime start, int moves, string player)> games = new();

    /// <summary>
    /// <<sumary>> Punkt wejścia serwera.
    /// Ustawia tytuł/konsolę, tworzy (lub aktualizuje) bazę SQLite, startuje nasłuchiwanie TCP
    /// i uruchamia pętlę akceptującą połączenia. Zatrzymuje serwer po wciśnięciu Enter.
    /// </summary>
    private static async Task Main()
    {
        Console.Title = $"Saper.Server :{Port}";
        Console.WriteLine($"[SERVER] Start na porcie {Port}…");

        using (var db = new ServerDb()) db.Database.EnsureCreated();

        var listener = new TcpListener(IPAddress.Any, Port);
        listener.Start();
        _ = AcceptLoopAsync(listener);

        Console.WriteLine("[SERVER] Enter = stop");
        Console.ReadLine();
        listener.Stop();
    }

    /// <summary>
    /// <<sumary>> Pętla akceptująca przychodzące połączenia TCP.
    /// Dla każdego klienta uruchamia asynchroniczną obsługę <see cref="HandleClientAsync"/>.
    /// Kończy działanie po zatrzymaniu listenera.
    /// </summary>
    private static async Task AcceptLoopAsync(TcpListener l)
    {
        while (true)
        {
            TcpClient? c = null;
            try { c = await l.AcceptTcpClientAsync(); _ = HandleClientAsync(c); }
            catch (ObjectDisposedException) { break; }
            catch (Exception ex) { Console.WriteLine("[ACCEPT] " + ex.Message); c?.Close(); }
        }
    }

    /// <summary>
    /// <<sumary>> Szybkie rozpoznanie typu wiadomości JSON.
    /// Zwraca wartość pola "type" lub pusty string, jeśli JSON jest nieprawidłowy / bez pola.
    /// </summary>
    private static string TypeOfJson(string json)
    {
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(json);
            return doc.RootElement.TryGetProperty("type", out var t) ? t.GetString() ?? "" : "";
        }
        catch { return ""; }
    }

    /// <summary>
    /// <<sumary>> Obsługa pojedynczego klienta:
    /// czyta linie JSON, rozpoznaje typ i reaguje:
    /// - CreateGameReq → zakłada nową grę + zapis do DB, odsyła CreateGameResp,
    /// - RevealReq → odsłania pola i ewentualnie domyka grę (PersistFinishAsync), odsyła GameDelta,
    /// - ToggleFlagReq → przełącza flagę, odsyła GameDelta,
    /// - GetTopReq → zwraca Top 10 wyników (GetTopResp) wg filtrów,
    /// - inne → błąd "Unknown type".
    /// Loguje każdą linię wejściową jako [RAW].
    /// </summary>
    private static async Task HandleClientAsync(TcpClient client)
    {
        var ep = client.Client.RemoteEndPoint;
        Console.WriteLine($"[CONN] {ep}");
        using var stream = client.GetStream();
        using var reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
        using var writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };

        try
        {
            while (true)
            {
                var line = await reader.ReadLineAsync();
                if (line is null) break;
                Console.WriteLine("[RAW] " + line);

                var kind = TypeOfJson(line);
                switch (kind)
                {
                    case "CreateGameReq":
                        {
                            var req = Protocol.From<CreateGameReq>(line)!;
                            var seed = Random.Shared.Next();
                            var board = new Board(req.width, req.height, req.mines, seed);
                            var id = Guid.NewGuid().ToString("N");
                            games[id] = (board, DateTime.UtcNow, 0, req.player);

                            using var db = new ServerDb();
                            db.Games.Add(new GameEntity
                            {
                                Id = id,
                                PlayerName = string.IsNullOrWhiteSpace(req.player) ? "guest" : req.player.Trim(),
                                StartedAt = DateTime.UtcNow,
                                Width = req.width,
                                Height = req.height,
                                Mines = req.mines,
                                Seed = seed,
                                Moves = 0,
                                DurationMs = 0
                            });
                            await db.SaveChangesAsync();

                            await writer.WriteAsync(Protocol.ToLine(new CreateGameResp(id, req.width, req.height, req.mines, seed)));
                            break;
                        }
                    case "RevealReq":
                        {
                            var req = Protocol.From<RevealReq>(line)!;
                            if (!games.TryGetValue(req.gameId, out var g))
                            { await writer.WriteAsync(Protocol.ToLine(new ErrorMsg("No game"))); break; }

                            var opened = new List<CellOpen>();
                            foreach (var c in g.board.Reveal(req.x, req.y)) opened.Add(c);
                            g.moves++; games[req.gameId] = (g.board, g.start, g.moves, g.player);

                            if (g.board.IsGameOver)
                                await PersistFinishAsync(req.gameId, g, g.board);

                            await writer.WriteAsync(Protocol.ToLine(new GameDelta(
                                req.gameId, opened.ToArray(), Array.Empty<CellFlag>(),
                                g.board.IsGameOver, g.board.PlayerWon,
                                g.board.MinesLeft, g.board.RevealedCount)));
                            break;
                        }
                    case "ToggleFlagReq":
                        {
                            var req = Protocol.From<ToggleFlagReq>(line)!;
                            if (!games.TryGetValue(req.gameId, out var g))
                            { await writer.WriteAsync(Protocol.ToLine(new ErrorMsg("No game"))); break; }

                            var cf = g.board.ToggleFlag(req.x, req.y);

                            await writer.WriteAsync(Protocol.ToLine(new GameDelta(
                                req.gameId, Array.Empty<CellOpen>(), new[] { cf },
                                g.board.IsGameOver, g.board.PlayerWon,
                                g.board.MinesLeft, g.board.RevealedCount)));
                            break;
                        }
                    // -------------- TOP 10 --------------
                    case "GetTopReq":
                        {
                            var req = Protocol.From<GetTopReq>(line)!;
                            int take = req.limit <= 0 ? 10 : req.limit;

                            using var db = new ServerDb();
                            var q = db.Games.AsNoTracking()
                                .Where(g => g.FinishedAt != null && g.Won == true);

                            if (req.width.HasValue) q = q.Where(g => g.Width == req.width.Value);
                            if (req.height.HasValue) q = q.Where(g => g.Height == req.height.Value);
                            if (req.mines.HasValue) q = q.Where(g => g.Mines == req.mines.Value);

                            var raw = await q
                                .OrderBy(g => g.DurationMs)
                                .ThenBy(g => g.Moves)
                                .ThenBy(g => g.FinishedAt)
                                .Take(take)
                                .Select(g => new
                                {
                                    g.PlayerName,
                                    g.Width,
                                    g.Height,
                                    g.Mines,
                                    g.Moves,
                                    g.DurationMs,
                                    g.Won,
                                    g.FinishedAt
                                })
                                .ToListAsync();

                            var list = raw.Select(g => new TopScore(
                                g.PlayerName,
                                g.Width,
                                g.Height,
                                g.Mines,
                                g.Moves,
                                g.DurationMs,
                                g.Won ?? false,
                                (g.FinishedAt ?? DateTime.UtcNow).ToString("s")
                            )).ToArray();

                            await writer.WriteAsync(Protocol.ToLine(new GetTopResp(list)));
                            break;
                        }
                    default:
                        {
                            await writer.WriteAsync(Protocol.ToLine(new ErrorMsg("Unknown type")));
                            break;
                        }
                }
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine("[CLIENT ERR] " + ex.Message);
        }
        finally
        {
            Console.WriteLine($"[DISC] {ep}");
            client.Close();
        }
    }

    /// <summary>
    /// <<sumary>> Utrwala wynik zakończonej gry w bazie danych:
    /// uzupełnia liczbę ruchów, status wygranej/przegranej, czas zakończenia
    /// oraz czas trwania (ms) liczony od startu gry.
    /// </summary>
    private static async Task PersistFinishAsync(string id, (Board board, DateTime start, int moves, string player) g, Board b)
    {
        using var db = new ServerDb();
        var e = await db.Games.FindAsync(id);
        if (e is null) return;
        e.Moves = g.moves;
        e.Won = b.PlayerWon;
        e.FinishedAt = DateTime.UtcNow;
        e.DurationMs = (int)(e.FinishedAt.Value - g.start).TotalMilliseconds;
        await db.SaveChangesAsync();
    }
}
